---
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- dense
- generated_from_trainer
- dataset_size:16384
- loss:MultipleNegativesRankingLoss
- dataset_size:67712
base_model: cointegrated/rubert-tiny2
widget:
- source_sentence: аренда нивелира Вид услуги Оборудование, производство
  sentences:
  - 'Демонтаж/слом/снос /вывоз Вид услуги: Строительство | Гарантия: Бригада 5–20
    человек | График работы: от 28800 до 68400 | График работы, дни недели: пн вт
    ср чт пт сб | Тип услуги: Снос и демонтаж Демонтажние работы под ключ!

    Демонтаж любой сложности, перепланировка.


    Оплата после выполнения работ.

    Цену можете уточнить по телефону,Вайбер,ватсап.

    Выезд на объект для замера в удобное для вас врем'
  - 'Аренда инструментов Вид услуги: Оборудование, производство | Тип услуги: Аренда
    оборудования прокат и аренда инструмента звоните уточняйте

    Пресс клещи для металлопластиковых труб 450р

    Лазерный уровень-400р

    Бензопила цепная SHTIL-550р

    Плиткорез ручной 70см-500р

    Плиткорез рельсовый Matrix 700мм'
  - 'Прокат инструмента и техники Вид услуги: Оборудование, производство | Тип услуги:
    Аренда оборудования | График работы: от 32400 до 64800 Рады приветствовать вас!
    Уважаемые клиенты нашего сервиса "Прокат №1 инструмента"!


    🧨 Быстрое оформление! Без залога!


    Наш ассортимент инструмента в прокат(цена за сутки):


    · Аккумуляторная дрель-шуру'
- source_sentence: машинная вышивка
  sentences:
  - "Замена автостекла Вид услуги: Автосервис, аренда | Тип услуги: Автосервис | Гарантия:\
    \ Опыт работы 8 | График работы: от 36000 до 75600 | Тип услуги автосервиса: Диагностика\
    \ и ремонт авто | Тип автосервиса: Официальный сервис | Марка авто: AC Acura Adler\
    \ AITO Alfa Alpina Alpine AMC AM Amico Amphicar Arcfox Ariel Aro Asia Aston Auburn\
    \ Audi Aurus Austin Austin Autobianchi Avatr BAIC Bajaj Baltijas Baojun Barkas\
    \ BAW Bentley Bertone Bilenkin Bio Bitter BMW Borgward Brilliance Bristol Bufori\
    \ Bugatti Buick BYD Cadillac Callaway Caterham Changan ChangFeng Changhe Chery\
    \ CheryExeed Chevrolet Chrysler Citroen Cizeta Coggiola Cord Cupra Dacia Dadi\
    \ Daewoo Daihatsu Daimler Datsun Delage DeLorean Denza Derways DeSoto De DKW Dodge\
    \ Dongfeng Doninvest Donkervoort DS DW Eagle Eagle E-Car Evolute Excalibur Exeed\
    \ FAW Ferrari FIAT Fisker Ford Foton FSO Fuqi GAC Geely Genesis Geo GMC Golden\
    \ Gonow Gordon GP Graham-Paige Great Groz Hafei Haima Hanomag Haval Hawtai Heinkel\
    \ Hindustan HiPhi Hispano-Suiza Honda Hongqi Horch HSV Huanghai Hudson Hummer\
    \ Hyundai Imperial Infiniti Innocenti Invicta Iran Isdera Isuzu Iveco JAC Jaguar\
    \ Jeep Jensen Jetour Jetta Jinbei JMC Jonway Kaiyi Khazar Kia Koenigsegg KTM Lamborghini\
    \ Lancia Land Landwind LDV Leapmotor Lexus Leyland Lichi LIFAN Ligier Lincoln\
    \ LiXiang Lotus LTI Lucid Luxgen Lynk & Mahindra Marcos Marlin Marussia Maruti\
    \ Maserati Maybach Mazda McLaren Mega Mercedes-Benz Mercury Metrocab MG Microcar\
    \ Minelli MINI Mitsubishi Mitsuoka Morgan Morris Nash Neta NIO Nissan Noble Nysa\
    \ Oldsmobile OMODA Opel Ora Osca Oshan Packard Pagani Panhard & Panoz Peugeot\
    \ PGO Piaggio Plymouth Polestar Pontiac Porsche Premier Proton PUCH Puma Qoros\
    \ Qvale RAM Ravon Reliant Renaissance Renault Renault Rezvani Rimac Rivian Rocar\
    \ Roewe Rolls-Royce Ronart Rover Saab Saic Saipa Saleen Santana Saturn Scion SEAT\
    \ Seres Shuanghuan Simca Skoda Skywell SMA Smart SOL Sollers Spyker SsangYong\
    \ Steyr Studebaker Subaru Suzuki Talbot Tank Tata Tatra Tazzari Tesla Think Tianma\
    \ Tianye Toyota Trabant Tramontana Triumph TVR Ultima Vauxhall Vector Venturi\
    \ Volkswagen Volvo Vortex Voyah Wanderer Wartburg Weltmeister Westfield Wiesmann\
    \ Willys W Wuling Xin XPeng Zastava Zeekr Zenos Zenvo Zibar ZOTYE Zuk ZX Автокам\
    \ Апал Богдан ВАЗ (LADA) ВИС ГАЗ ЕрАЗ ЗАЗ ЗИЛ ЗиС ИЖ Канонир Комбат ЛуАЗ Москвич\
    \ РАФ Руссо-Балт СМЗ ТагАЗ УАЗ Polar \U0001F31FЗамена автостекол – это услуга,\
    \ предназначенная для восстановления прозрачности и целостности стекол вашего\
    \ автомобиля. \n\U0001F31F Мы предлагаем полный спектр услуг по замене стекол,\
    \ включая замену лобового"
  - 'Машинная вышивка от 1 дня Вид услуги: Бытовые услуги | Тип услуги: Пошив и ремонт
    одежды Машинная вышивка на одежде, разработка программ машинной вышивки для бытовых
    и промышленных машин


    🔹Машинная вышивка на худи, халатах, шапках, футболках, на полотенцах, носках,
    на крое, спецовках, тек'
  - "Аренда фотостудии с циклорамой в центре СПб Вид услуги: Фото- и видеосъёмка |\
    \ График работы: от 32400 до 79200 Здравствуйте!\n\n☝ Начинающим фотографам у\
    \ нас всегда оказывается всесторонняя помощь:\r\n- настроим фотоаппарат,\r\n-\
    \ поставим свет,\r\n- поможем выстроить освещение по референсам.\n\nВ нашей чистой\
    \ и светлой"
- source_sentence: аренда электровелосипед
  sentences:
  - "Парикмахер/колорист Вид услуги: Красота, здоровье | Тип услуги: Услуги парикмахера\
    \ | Где вы оказываете услуги: В салоне | Ваши клиенты: Женщины Мужчины | Кто оказывает\
    \ услуги: Женщина | Специальность или сфера: Стрижка, окрашивание, укладка Доверяйте\
    \ свои волосы профессионалам☝️ \nМеня зовут Ксения, колорист/мастер-универсал\
    \ парикмахерских услуг\U0001F64C\nЯ считаю, что стрижка - это ювелирная работа\U0001F48E\
    \nОкрашивание - это целый спектр красок и оттенко"
  - 'Мокрая стяжка пола. Бетонные работы Вид услуги: Ремонт и отделка | Тип услуги:
    Полы и напольные покрытия | Гарантия: Бригада 2–4 человека | График работы: от
    0 до 86340 | График работы, дни недели: пн вт ср чт пт вс Мокрая стяжка по маякам
    . Выполняем работу качественно в срок .'
  - 'Электровелосипед аренда Вид услуги: Другое | Гарантия: на работу АРЕНДА ЭЛЕКТРОВЕЛОСИПЕДА
    ДЛЯ КУРЬЕРОВ

    БЕЗ ЗАЛОГА


    аренда первая неделя 2500

    аренда с 2 АКП

    До 10-12 часов работы без подзарядки

    До 100-120 км хода (2 АКБ)

    Категория без прав

    Окупает аренду за 1-2 часа'
- source_sentence: скупка мониторов Вид услуги
  sentences:
  - "Изготовление ключей для домофона. Без дубликата Вид услуги: Бытовые услуги |\
    \ Тип услуги: Изготовление ключей | График работы, дни недели: пн вт ср чт пт\
    \ сб вс Изготовление ключей для домофона в коминтерновском районе, бесплатная\
    \ доставка от 2х ключей. Возможна доставка в день обращения. Гарантия. \nВозможно\
    \ изготовление без вашего ключа !!! \nСкидки! от 5 клю"
  - 'Скупка компьютеров мониторов ноутбуков принтеров Вид услуги: Место оказания услуг
    !!!!БИТЫЕ ТЕЛЕВИЗОРЫ И МОНИТОРЫ НЕ БЕРЕМ!!!! ‼️


    Скупка/выкуп оргтехники электроники от 2014 года!!


    ПРИЕДЕМ В ДЕНЬ обращения для оценки техники и согласования цены.


    Возможна оценка по фото!


    Быстрый'
  - "Торты на заказ, Бенто торт. торты кг Вид услуги: Доставка еды и продуктов | Тип\
    \ услуги: Другое Бенто тортик с  любым кремовым декором -1500\U0001F525\nЯ -Катя,\
    \ и я помогу сделать ваш праздник вкуснее и ярче!\n•\nЧто можно заказать? \U0001F447\
    \ \n•бенто мини( милый презент как в подарок, так и для небольших праздников"
- source_sentence: мотобур в аренду Вид услуги Оборудование, производство
  sentences:
  - 'Прием металлолома в Ангарске, самовывоз и демонтаж Вид услуги: Вывоз мусора и
    вторсырья | График работы: от 28800 до 61200 | График работы, дни недели: пн вт
    ср чт пт сб Мы - одна из компаний крупнейшего холдинга СГМК-Трейд, который является
    лидером среди предприятий горно-металлургической отрасли России.

    Работаем напрямую от завода, поэтому наши цены всегда самые выс'
  - 'Услуги косметолога Вид услуги: Красота, здоровье | Тип услуги: Косметология |
    Где вы оказываете услуги: У себя дома | Ваши клиенты: Женщины | Кто оказывает
    услуги: Женщина Дорогие дамы и девушки, приглашаю на процедуру BioReVitaPeel 💫

    Пилинг и восстановление холеного сияния кожи в одной процедуре, без инъекций!

    Разницу в качестве, текстуре кожи заметите уже после первог'
  - 'Аренда строительного инструмента без залога Вид услуги: Оборудование, производство
    | Тип услуги: Аренда оборудования | График работы: от 21600 до 79200 АРЕНДА /
    ПРОКАТ ИНСТРУМЕНТА  ОБОРУДОВАНИЯ БЕЗ ЗАЛОГА


    Прокатная компания PROKAT-строй Казань предлагает широкий выбор строительной техники
    и оборудования в прокат!


    🌟 Выдача Строительного инструмента'
pipeline_tag: sentence-similarity
library_name: sentence-transformers
---

# SentenceTransformer based on cointegrated/rubert-tiny2

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [cointegrated/rubert-tiny2](https://huggingface.co/cointegrated/rubert-tiny2). It maps sentences & paragraphs to a 312-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, classification, clustering, and more.

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [cointegrated/rubert-tiny2](https://huggingface.co/cointegrated/rubert-tiny2) <!-- at revision e8ed3b0c8bbf4fb6984c3de043bf7d2f4e5969ae -->
- **Maximum Sequence Length:** 128 tokens
- **Output Dimensionality:** 312 dimensions
- **Similarity Function:** Cosine Similarity
- **Supported Modality:** Text
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/huggingface/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'transformer_task': 'feature-extraction', 'modality_config': {'text': {'method': 'forward', 'method_output_name': 'last_hidden_state'}}, 'module_output_name': 'token_embeddings', 'architecture': 'BertModel'})
  (1): Pooling({'embedding_dimension': 312, 'pooling_mode': 'cls', 'include_prompt': True})
  (2): Normalize({})
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```
Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'мотобур в аренду Вид услуги Оборудование, производство',
    'Аренда строительного инструмента без залога Вид услуги: Оборудование, производство | Тип услуги: Аренда оборудования | График работы: от 21600 до 79200 АРЕНДА / ПРОКАТ ИНСТРУМЕНТА \xa0ОБОРУДОВАНИЯ БЕЗ ЗАЛОГА\n\nПрокатная компания PROKAT-строй Казань предлагает широкий выбор строительной техники и оборудования в прокат!\n\n🌟 Выдача Строительного инструмента',
    'Прием металлолома в Ангарске, самовывоз и демонтаж Вид услуги: Вывоз мусора и вторсырья | График работы: от 28800 до 61200 | График работы, дни недели: пн вт ср чт пт сб Мы - одна из компаний крупнейшего холдинга СГМК-Трейд, который является лидером среди предприятий горно-металлургической отрасли России.\nРаботаем напрямую от завода, поэтому наши цены всегда самые выс',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 312]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities)
# tensor([[1.0000, 0.6699, 0.2844],
#         [0.6699, 1.0000, 0.4177],
#         [0.2844, 0.4177, 1.0000]])
```
<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset

* Size: 67,712 training samples
* Columns: <code>sentence_0</code> and <code>sentence_1</code>
* Approximate statistics based on the first 100 samples:
  |          | sentence_0                                                                        | sentence_1                                                                          |
  |:---------|:----------------------------------------------------------------------------------|:------------------------------------------------------------------------------------|
  | type     | string                                                                            | string                                                                              |
  | modality | text                                                                              | text                                                                                |
  | details  | <ul><li>min: 3 tokens</li><li>mean: 11.63 tokens</li><li>max: 33 tokens</li></ul> | <ul><li>min: 48 tokens</li><li>mean: 87.02 tokens</li><li>max: 128 tokens</li></ul> |
* Samples:
  | sentence_0                                                                                 | sentence_1                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
  |:-------------------------------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
  | <code>доставка воды в бассейн</code>                                                       | <code>Доставка воды водовозом Вид услуги: Грузоперевозки \| Тип услуги: По городу Доставка технической воды в СПБ и Лен. Обл.  <br> Компания Маяк СГ <br>Если вам нужно:<br>Заполнить колодец<br>Заполнить бассейн <br>Доставить воду на дачу<br>Привезти тех.воду на строительную площадку <br>Доставить воду</code>                                                                                                                                                         |
  | <code>сруб бани Вид услуги Строительство</code>                                            | <code>Баня из сруба, печи "inox",3-4 дня Вид услуги: Строительство \| Гарантия: Бригада 2–4 человека \| График работы: от 28800 до 68400 \| График работы, дни недели: пн вт ср чт пт сб вс \| Тип услуги: Строительство гаражей, бань, веранд Строим бани под ключ с 1998 года — изготавливаем и собираем срубы бань из зимнего леса.<br><br>Что мы предлагаем:<br><br>* Баня из сруба за 3–4 дня — быстро, надёжно, без посредников.  <br>* Фундамент ленточный + цок</code> |
  | <code>укладка плитки фартук Тип услуги Плиточные работы Вид услуги Ремонт и отделка</code> | <code>Мастер.Укладка Керамогранита, кухонного фартука Вид услуги: Ремонт и отделка \| Тип услуги: Плиточные работы \| Гарантия: Бригада 1 человек \| График работы: от 32400 до 64800 \| График работы, дни недели: пн вт ср чт пт сб вс Добрый день!  <br>Работаю по небольшим объемам керамогранита и плитки. Столешницы, кухонные фартуки , короба после переделки труб.<br><br>От больших объемов ушел, так как есть большой объект и в ближайшие пол г</code>             |
* Loss: [<code>MultipleNegativesRankingLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#multiplenegativesrankingloss) with these parameters:
  ```json
  {
      "scale": 20.0,
      "similarity_fct": "cos_sim",
      "gather_across_devices": false,
      "directions": [
          "query_to_doc"
      ],
      "partition_mode": "joint",
      "hardness_mode": null,
      "hardness_strength": 0.0
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `per_device_train_batch_size`: 128
- `num_train_epochs`: 1
- `fp16`: True
- `per_device_eval_batch_size`: 128
- `multi_dataset_batch_sampler`: round_robin

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `per_device_train_batch_size`: 128
- `num_train_epochs`: 1
- `max_steps`: -1
- `learning_rate`: 5e-05
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: None
- `warmup_steps`: 0
- `optim`: adamw_torch_fused
- `optim_args`: None
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `optim_target_modules`: None
- `gradient_accumulation_steps`: 1
- `average_tokens_across_devices`: True
- `max_grad_norm`: 1
- `label_smoothing_factor`: 0.0
- `bf16`: False
- `fp16`: True
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `use_liger_kernel`: False
- `liger_kernel_config`: None
- `use_cache`: False
- `neftune_noise_alpha`: None
- `torch_empty_cache_steps`: None
- `auto_find_batch_size`: False
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `include_num_input_tokens_seen`: no
- `log_level`: passive
- `log_level_replica`: warning
- `disable_tqdm`: False
- `project`: huggingface
- `trackio_space_id`: None
- `trackio_bucket_id`: None
- `trackio_static_space_id`: None
- `per_device_eval_batch_size`: 128
- `prediction_loss_only`: True
- `eval_on_start`: False
- `eval_do_concat_batches`: True
- `eval_use_gather_object`: False
- `eval_accumulation_steps`: None
- `include_for_metrics`: []
- `batch_eval_metrics`: False
- `save_only_model`: False
- `save_on_each_node`: False
- `enable_jit_checkpoint`: False
- `push_to_hub`: False
- `hub_private_repo`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_always_push`: False
- `hub_revision`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `restore_callback_states_from_checkpoint`: False
- `full_determinism`: False
- `seed`: 42
- `data_seed`: None
- `use_cpu`: False
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `parallelism_config`: None
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `dataloader_prefetch_factor`: None
- `dataloader_multiprocessing_context`: None
- `dataloader_in_order`: True
- `remove_unused_columns`: True
- `label_names`: None
- `train_sampling_strategy`: random
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `ddp_static_graph`: None
- `ddp_backend`: None
- `ddp_timeout`: 1800
- `fsdp`: None
- `fsdp_config`: None
- `deepspeed`: None
- `debug`: []
- `skip_memory_metrics`: True
- `do_predict`: False
- `resume_from_checkpoint`: None
- `local_rank`: -1
- `prompts`: None
- `batch_sampler`: batch_sampler
- `multi_dataset_batch_sampler`: round_robin
- `router_mapping`: {}
- `learning_rate_mapping`: {}
- `warmup_ratio`: None

</details>

### Training Logs
| Epoch  | Step | Training Loss |
|:------:|:----:|:-------------:|
| 0.9452 | 500  | 1.1306        |


### Training Time
- **Training**: 1.7 minutes

### Framework Versions
- Python: 3.13.15
- Sentence Transformers: 5.7.0
- Transformers: 5.16.1
- PyTorch: 2.11.0+cu128
- Accelerate: 1.14.0
- Datasets: 4.8.5
- Tokenizers: 0.23.1

## Additional Resources

- [Training and Finetuning Embedding Models with Sentence Transformers](https://huggingface.co/blog/train-sentence-transformers): the end-to-end guide for training or finetuning Sentence Transformer models.
- [Introduction to Matryoshka Embedding Models](https://huggingface.co/blog/matryoshka): variable-size embeddings that can be truncated with minimal quality loss.
- [Binary and Scalar Embedding Quantization for Significantly Faster & Cheaper Retrieval](https://huggingface.co/blog/embedding-quantization): post-training compression of embedding vectors.
- [Multimodal Embedding & Reranker Models with Sentence Transformers](https://huggingface.co/blog/multimodal-sentence-transformers): use text, image, audio, and video models through the same API.
- [Training and Finetuning Multimodal Embedding & Reranker Models with Sentence Transformers](https://huggingface.co/blog/train-multimodal-sentence-transformers): train multimodal embedding models, with a Visual Document Retrieval walkthrough.

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

#### MultipleNegativesRankingLoss
```bibtex
@misc{oord2019representationlearningcontrastivepredictive,
      title={Representation Learning with Contrastive Predictive Coding},
      author={Aaron van den Oord and Yazhe Li and Oriol Vinyals},
      year={2019},
      eprint={1807.03748},
      archivePrefix={arXiv},
      primaryClass={cs.LG},
      url={https://arxiv.org/abs/1807.03748},
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->